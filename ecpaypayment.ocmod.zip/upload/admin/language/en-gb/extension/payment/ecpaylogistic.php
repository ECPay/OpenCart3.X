<?php
// Heading
$_['heading_title']        = '綠界物流模組';

// Text
$_['text_ecpaylogistic']   = '<a href="https://www.ecpay.com.tw/" target="_blank"><img src="view/image/payment/ecpaylogistic.png" /></a>';
$_['text_success']         = '成功：您已成功修改綠界物流模組模組設定！';
$_['text_edit']            = '編輯綠界物流模組';
$_['text_payment']         = '付款模組';
$_['entry_order_status']   = '訂單狀態';