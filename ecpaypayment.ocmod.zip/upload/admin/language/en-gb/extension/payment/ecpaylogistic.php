<?php
// Heading
$_['heading_title']			= 'ECPay 超商取貨付款';

// Text
$_['text_ecpaylogistic'] 	= '<a href="https://www.ecpay.com.tw/" target="_blank"><img src="view/image/payment/ecpaylogistic.png" /></a>';
$_['text_success']			= '成功：您已成功修改 ECPay 超商取貨付款設定!';
$_['text_edit']				= 'ECPay 超商取貨付款';
$_['text_payment']			= 'Payment';
$_['entry_order_status']	= '訂單狀態';


?>