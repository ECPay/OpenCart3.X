<?php
// Heading
$_['heading_title']		= '綠界物流模組';

// Text
$_['text_ecpaylogistic'] 	= '<a href="https://www.ecpay.com.tw/" target="_blank"><img src="view/image/payment/ecpaylogistic.png" /></a>';
$_['text_success']		= '成功：您已成功修改綠界物流模組設定!';
$_['text_edit']			= '綠界物流模組';
$_['text_payment']		= 'Payment';
$_['entry_order_status']	= '訂單狀態';


?>