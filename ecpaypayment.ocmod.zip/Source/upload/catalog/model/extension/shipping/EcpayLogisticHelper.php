<?php

require_once('ModuleHelper.php');

use Ecpay\Shipping\ModuleHelper;

class EcpayLogisticHelper extends ModuleHelper
{
    /**
     * EcpayPaymentHelper constructor.
     */
    public function __construct()
    {
        parent::__construct();

    }

}
