<?php
// Text
$_['text_title']                         = '綠界超商取貨付款';
$_['ecpaylogistic_text_checkout_button'] = '結帳';
