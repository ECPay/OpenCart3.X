<?php
// Text
$_['ecpayinvoice_text_title'] = '綠界電子發票';